import { Component } from '@angular/core';

@Component({
  selector: 'app-button',
  imports: [],
  templateUrl: './button.component.html',
  styleUrl: './button.component.css'
})
export class ButtonComponent {
  nazwa: String = "Pomocy"
  liczba1: number =0;
  liczba2: number =0; 
  
  fun(): void{
    this.nazwa = "cokolwiek"
  }
  przypisz1liczbe($event: any){
    console.log($event)
  }
  przypisz2liczbe(){

  }
}
