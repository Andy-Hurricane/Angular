import { Component } from '@angular/core';

@Component({
  selector: 'app-conteiner',
  imports: [],
  templateUrl: './conteiner.component.html',
  styleUrl: './conteiner.component.css'
})
export class ConteinerComponent {

}
