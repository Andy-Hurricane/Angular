import { Component } from '@angular/core';

@Component({
  selector: 'app-img',
  imports: [],
  templateUrl: './img.component.html',
  styleUrl: './img.component.css'
})
export class ImgComponent {

}
