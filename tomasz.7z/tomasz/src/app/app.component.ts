import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {ButtonComponent} from "./button/button.component";
import {ConteinerComponent} from "./conteiner/conteiner.component"
import { ImgComponent } from './img/img.component';
import { InputTextComponent } from './input-text/input-text.component';
import { LabelComponent } from './label/label.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ButtonComponent, ConteinerComponent, ImgComponent, InputTextComponent, LabelComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'tomasz';
}
