import { Component } from '@angular/core';


@Component({
  selector: 'app-button',
  imports: [],
  templateUrl: './button.component.html',
  styleUrl: './button.component.css'
})
export class ButtonComponent {
  nazwa: String = "Pomocy";
  liczba1: number = 0;
  liczba2: number = 0; 
  
  fun(): void{
    
    this.nazwa = (this.liczba1 + this.liczba2).toString();
  }
  przypisz1liczbe($event: any){
    console.log($event.target.value);
    this.liczba1 = parseInt($event.target.value);
  }
  przypisz2liczbe($event: any){
    console.log($event.target.value);
    this.liczba2 = parseInt($event.target.value);
  }
}
